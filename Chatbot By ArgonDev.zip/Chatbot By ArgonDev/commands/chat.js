import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('chat')

  .setDescription('Chat with the AI assistant')

  .addStringOption(option =>

    option.setName('message')

      .setDescription('The message you want to send to the AI')

      .setRequired(true)

  );

export async function execute(interaction) {

  const prompt = interaction.options.getString('message');

  if (!interaction.deferred && !interaction.replied) {

    await interaction.deferReply();

  }

  try {

    const aiResponse = await generateChatCompletion(prompt);

    await interaction.editReply({

      content: aiResponse,

      allowedMentions: { repliedUser: false }

    });

  } catch (error) {

    console.error('❌ Error in /chat:', error.message);

    if (interaction.deferred || interaction.replied) {

      await interaction.editReply('❌ An error occurred while generating a response from AI.');

    } else {

      await interaction.reply({

        content: '❌ An error occurred while generating a response from AI.',

        ephemeral: true

      });

    }

  }

}