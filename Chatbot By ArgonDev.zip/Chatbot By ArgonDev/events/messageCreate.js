import { Events } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

import { getAutoChannel } from '../utils/channelManager.js';

import fs from 'fs';

const historyPath = './data/history.json';

function saveToHistory(userId, messages) {

  let history = fs.existsSync(historyPath)

    ? JSON.parse(fs.readFileSync(historyPath))

    : {};

  history[userId] = messages;

  fs.writeFileSync(historyPath, JSON.stringify(history, null, 2));

}

function loadHistory(userId) {

  if (!fs.existsSync(historyPath)) return [];

  const history = JSON.parse(fs.readFileSync(historyPath));

  return history[userId] || [];

}

export default {

  name: Events.MessageCreate,

  async execute(message) {

    if (message.author.bot) return;

    const autoChannel = getAutoChannel(message.guild?.id);

    const botWasMentioned = message.mentions.has(message.client.user);

    const repliedToBot = message.reference && (

      await message.channel.messages.fetch(message.reference.messageId)

    )?.author.id === message.client.user.id;

    const shouldReply = botWasMentioned || repliedToBot || (autoChannel && message.channel.id === autoChannel);

    if (!shouldReply) return;

    const userId = message.author.id;

    const history = loadHistory(userId);

    const messages = [

      ...history.slice(-10),

      { role: 'user', content: message.content }

    ];

    try {

      const reply = await generateChatCompletion(messages);

      messages.push({ role: 'assistant', content: reply });

      saveToHistory(userId, messages);

      message.reply(reply);

    } catch (err) {

      console.error('Message reply error:', err);

      message.reply('❌ Error while replying.');

    }

  }

};