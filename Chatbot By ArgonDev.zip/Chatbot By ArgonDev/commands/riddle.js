import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('riddle')

  .setDescription('Get a fun riddle to solve!');

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Give me one clever and fun riddle. Format it as:

Riddle: <question>

Answer: ||<answer hidden in spoiler tags for Discord>||`;

    

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Riddle error:', error);

    await interaction.editReply({ content: '❌ Failed to generate a riddle. Please try again later.' });

  }

}