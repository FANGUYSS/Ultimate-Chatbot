import {

  SlashCommandBuilder,

  ActionRowBuilder,

  StringSelectMenuBuilder,

  EmbedBuilder,

  ComponentType

} from 'discord.js';

export const data = new SlashCommandBuilder()

  .setName('help')

  .setDescription('View all available commands by category');

export async function execute(interaction) {

  const categories = {

    "all": {

      name: "<:book:1396498861874221257> All Commands",

      value:

        '`/chat`, `/define`, `/delete_history`, `/explain`, `/fact`, `/help`, `/pickup-line`, `/remove-channel`, `/riddle`, `/roast`, `/set-channel`, `/translate`, `/truth-or-dare`, `/stats`'

    },

    "ai": {

      name: "<:brain:1396499242213703725> AI & Knowledge",

      value:

        '`/chat` - Ask anything to the AI\n' +

        '`/define` - Get the meaning of a word\n' +

        '`/explain` - Get an explanation of a topic\n' +

        '`/translate` - Translate text to another language'

    },

    "fun": {

      name: "<:giveaways:1396498728499679412> Fun & Games",

      value:

        '`/fact` - Get a random fact\n' +

        '`/pickup-line` - Get a funny pickup line\n' +

        '`/riddle` - Solve a riddle\n' +

        '`/roast` - Roast someone\n' +

        '`/truth-or-dare` - Play Truth or Dare'

    },

    "admin": {

      name: "<:settings:1396498960935424091> Channel & Admin",

      value:

        '`/set-channel` - Set bot channel\n' +

        '`/remove-channel` - Remove bot channel\n' +

        '`/stats` - View bot stats'

    },

    "memory": {

      name: "<:broom:1396499122558599358> Memory & Session",

      value:

        '`/delete_history` - Delete your chat history'

    }

  };

  const menu = new StringSelectMenuBuilder()

    .setCustomId('help-category')

    .setPlaceholder('Select a category')

    .addOptions([

      {

        label: '📖 All Commands',

        description: 'View all available commands',

        value: 'all'

      },

      {

        label: '🧠 AI & Knowledge',

        description: 'Ask, explain, define, translate',

        value: 'ai'

      },

      {

        label: '🎉 Fun & Games',

        description: 'Pickup lines, facts, riddles, etc.',

        value: 'fun'

      },

      {

        label: '⚙️ Channel & Admin',

        description: 'Manage bot channels',

        value: 'admin'

      },

      {

        label: '🧹 Memory & Session',

        description: 'Clear your chat history',

        value: 'memory'

      }

    ]);

  const row = new ActionRowBuilder().addComponents(menu);

  const initialEmbed = new EmbedBuilder()

    .setTitle('<a:robot:1396498236713209858> Bot Help Menu')

    .setDescription(' Hey there! Im your personal AI assistant built to make your Discord experience smarter and more enjoyable. I can automatically reply when you mention me, respond to your messages when you reply to me, and even chat in a dedicated channel that you set using the set-channel command. Im equipped with various helpful slash commands that make interaction smooth and engaging. You can discover all of my commands using the menu below and start exploring everything I can do for you! <a:bk_lighting:1396502712899604631> ')

    .setColor(0x5865f2)

    .setFooter({ text: 'Made By Argon Development ⚡', iconURL: interaction.client.user.displayAvatarURL() });

  const reply = await interaction.reply({

    embeds: [initialEmbed],

    components: [row],

    ephemeral: false

  });

  const collector = reply.createMessageComponentCollector({

    componentType: ComponentType.StringSelect,

    time: 60000

  });

  collector.on('collect', async (selectInteraction) => {

    const selected = selectInteraction.values[0];

    const category = categories[selected];

    const embed = new EmbedBuilder()

      .setTitle(`Category: ${category.name}`)

      .setDescription(category.value)

      .setColor(0x00bfff)

      .setFooter({ text: 'Argon Development ⚡', iconURL: interaction.client.user.displayAvatarURL() });

    await selectInteraction.update({ embeds: [embed], components: [row] });

  });

  collector.on('end', () => {

    reply.edit({ components: [] }).catch(() => {});

  });

}