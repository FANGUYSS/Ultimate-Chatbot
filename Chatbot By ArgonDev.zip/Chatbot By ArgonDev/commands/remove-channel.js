import { SlashCommandBuilder } from 'discord.js';

import fs from 'fs';

import path from 'path';

const filePath = path.join('./data/autoChannels.json');

export const data = new SlashCommandBuilder()

  .setName('remove-channel')

  .setDescription('Disable AI replies in this channel');

export async function execute(interaction) {

  try {

    const channelId = interaction.channel.id;

    let autoChannels = {};

    if (fs.existsSync(filePath)) {

      autoChannels = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    }

    if (autoChannels[channelId]) {

      delete autoChannels[channelId];

      fs.writeFileSync(filePath, JSON.stringify(autoChannels, null, 2));

      await interaction.reply({

        content: `<a:Stop:1396501151368745061> This channel has been removed from AI auto-replies.`,

        ephemeral: false,

      });

    } else {

      await interaction.reply({

        content: `<a:round:1396500867238203393> This channel was not enabled for auto-replies.`,

        ephemeral: false,

      });

    }

  } catch (err) {

    console.error('Error in /remove-channel:', err);

    await interaction.reply({

      content: `<:wrong:1396519712787136666> Failed to remove this channel. Try again later.`,

      ephemeral: false,

    });

  }

}