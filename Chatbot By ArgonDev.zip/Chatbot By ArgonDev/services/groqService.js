import Groq from 'groq-sdk';

import 'dotenv/config';

const groq = new Groq({

  apiKey: process.env.GROQ_API_KEY,

});

export async function generateChatCompletion(prompt) {

  try {

    const response = await groq.chat.completions.create({

      messages: [{ role: 'user', content: prompt }],

      model: 'llama3-70b-8192',

    });

    const message = response?.choices?.[0]?.message?.content?.trim();

    return message || "❌ AI gave an empty response.";

  } catch (error) {

    console.error("❌ Groq API Error:", error.message);

    return "❌ An error occurred while generating a response from AI.";

  }

}