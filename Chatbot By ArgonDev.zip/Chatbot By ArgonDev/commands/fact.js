import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('fact')

  .setDescription('Get a random interesting fact');

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Give me a random interesting fact that is surprising, educational, or fun.`;

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Fact command error:', error);

    await interaction.editReply({ content: '❌ Failed to fetch a fact. Try again later.' });

  }

}