import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('roast')

  .setDescription('Roast someone playfully')

  .addUserOption(option =>

    option.setName('user')

      .setDescription('Select a user to roast')

      .setRequired(true));

export async function execute(interaction) {

  const user = interaction.options.getUser('user');

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Roast ${user.username} in a funny and playful way. Keep it lighthearted and not offensive.`;

    const roast = await generateChatCompletion(prompt);

    await interaction.editReply({ content: `🔥 Roast for ${user}:\n${roast}` });

  } catch (error) {

    console.error('Roast error:', error);

    await interaction.editReply({ content: '❌ Failed to generate roast. Please try again later.' });

  }

}