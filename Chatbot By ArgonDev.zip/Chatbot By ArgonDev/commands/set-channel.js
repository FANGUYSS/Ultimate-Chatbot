import { SlashCommandBuilder } from 'discord.js';

import fs from 'fs';

import path from 'path';

const filePath = path.join('./data/autoChannels.json');

export const data = new SlashCommandBuilder()

  .setName('set-channel')

  .setDescription('Enable AI replies in this channel');

export async function execute(interaction) {

  try {

    const channelId = interaction.channel.id;

    let autoChannels = {};

    if (fs.existsSync(filePath)) {

      autoChannels = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    }

    autoChannels[channelId] = true;

    fs.writeFileSync(filePath, JSON.stringify(autoChannels, null, 2));

    await interaction.reply({

      content: `<a:tick:1396501315907227660> This channel is now enabled for AI replies.`,

      ephemeral: false,

    });

  } catch (err) {

    console.error('Error in /set-channel:', err);

    await interaction.reply({

      content: `<:wrong:1396519712787136666> Failed to set this channel. Try again later.`,

      ephemeral: false,

    });

  }

}