import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('define')

  .setDescription('Define any word or phrase')

  .addStringOption(option =>

    option.setName('term')

      .setDescription('The word or phrase to define')

      .setRequired(true)

  );

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  const term = interaction.options.getString('term');

  try {

    const prompt = `Define the word or phrase: "${term}". Provide a clear and concise explanation.`;

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Define command error:', error);

    await interaction.editReply({ content: '❌ Failed to define the term. Please try again.' });

  }

}