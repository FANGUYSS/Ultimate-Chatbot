import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('translate')

  .setDescription('Translate a given text to the selected language')

  .addStringOption(option =>

    option.setName('text')

      .setDescription('The text you want to translate')

      .setRequired(true))

  .addStringOption(option =>

    option.setName('language')

      .setDescription('The language you want to translate to (e.g., Spanish, French, Hindi)')

      .setRequired(true));

export async function execute(interaction) {

  const text = interaction.options.getString('text');

  const language = interaction.options.getString('language');

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Translate the following text to ${language}:\n"${text}"`;

    const reply = await generateChatCompletion(prompt);

    await interaction.editReply({ content: `**Translated to ${language}:**\n${reply}` });

  } catch (error) {

    console.error('Translation error:', error);

    await interaction.editReply({ content: '❌ Failed to translate. Please try again later.' });

  }

}