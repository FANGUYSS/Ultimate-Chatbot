import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('explain')

  .setDescription('Get a detailed explanation of any concept or topic')

  .addStringOption(option =>

    option.setName('topic')

      .setDescription('The topic you want explained')

      .setRequired(true)

  );

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  const topic = interaction.options.getString('topic');

  try {

    const prompt = `Explain the following topic in simple terms: "${topic}". Be detailed and easy to understand, Under 2000 characters.`;

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Explain command error:', error);

    await interaction.editReply({ content: '❌ Failed to explain the topic. Please try again.' });

  }

}