import { Client, GatewayIntentBits, Collection, REST, Routes, Partials } from 'discord.js';

import fs from 'fs';

import path from 'path';

import { fileURLToPath } from 'url';

import chalk from 'chalk';

import figlet from 'figlet';

import dotenv from 'dotenv';

import { generateChatCompletion } from './services/groqService.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

// Display banner

figlet('ArgonDev', (err, data) => {

  if (err) {

    console.log('[✗] Figlet error:', err);

    return;

  }

  console.log(chalk.cyan(data));

  console.log(chalk.greenBright('🚀 Starting up ArgonDev Made Discord Bot...\n'));

});

const client = new Client({

  intents: [

    GatewayIntentBits.Guilds,

    GatewayIntentBits.GuildMessages,

    GatewayIntentBits.MessageContent

  ],

  partials: [Partials.Channel]

});

client.commands = new Collection();

// Load commands

const commandsPath = path.join(__dirname, 'commands');

const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

console.log(chalk.yellow(`🔍 Found ${commandFiles.length} command file(s)`));

for (const file of commandFiles) {

  const filePath = path.join(commandsPath, file);

  const commandModule = await import(`file://${filePath}`);

  const command = commandModule.default || commandModule;

  if (command?.data && command?.execute) {

    client.commands.set(command.data.name, command);

    console.log(chalk.blueBright(`[✓] Loaded command: ${command.data.name}`));

  } else {

    console.log(chalk.red(`⚠️ Skipped invalid command file: ${file}`));

  }

}

// Register slash commands

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

const commands = client.commands.map(cmd => cmd.data.toJSON());

(async () => {

  try {

    console.log(chalk.blue('📡 Registering slash commands...'));

    await rest.put(

      Routes.applicationCommands(process.env.CLIENT_ID),

      { body: commands }

    );

    console.log(chalk.green('✅ Slash commands registered successfully.'));

  } catch (error) {

    console.error(chalk.red('❌ Failed to register slash commands:'), error);

  }

})();

// Set presence

client.once('ready', () => {

  console.log(chalk.greenBright(`\n[✓] Logged in as ${client.user.tag}`));

  client.user.setPresence({

    status: 'idle',

    activities: [

      { name: 'Made By Argon Development ⚡', type: 1 }

    ]

  });

});

// Load auto-channel list

function loadAutoChannels() {

  try {

    const data = fs.readFileSync('./data/autoChannels.json', 'utf8');

    return JSON.parse(data);

  } catch {

    return {};

  }

}

// Message event: AI replies + Help on mention only

client.on('messageCreate', async message => {

  if (message.author.bot) return;

  const autoChannels = loadAutoChannels();

  const mentioned = message.mentions.has(client.user);

  const isOnlyMention = message.content.trim() === `<@${client.user.id}>` || message.content.trim() === `<@!${client.user.id}>`;

  const repliedToBot = message.reference && message.mentions.repliedUser?.id === client.user.id;

  const isInAutoChannel = autoChannels[message.channel.id];

  // 💬 Just a mention = Show Help Embed

  if (isOnlyMention) {
      
    const embed = {

      title: '<a:robot:1396498236713209858> Welcome to Argon Development',

      description: [

         'Hello! Im your AI-powered assistant built by **Argon Development**.',  

  'You can use me in three ways:',  

  '> <:Chat:1399759588911480922> Mention me with a prompt — `@BotName your question`',  

  '> <:settings:1396498960935424091> Use the slash commands like `/help`, `/define`, `/translate` etc.',  

  '> <:brain:1396499242213703725> Enable auto AI responses in a channel using `/set-channel`',  

  'Need help? Use the slash command menu or explore the bot’s full capabilities.'
          

      ].join('\n'),

      color: 0x5865f2,

      footer: {

        text: 'Argon Development • Powering Smart Conversations',

      },

      timestamp: new Date(),

    };

    return message.reply({ embeds: [embed] });

  }

  // 🧠 Mention with message / replied / auto-channel = AI response

  if (mentioned || repliedToBot || isInAutoChannel) {

    const input = message.content.replaceAll(`<@${client.user.id}>`, '').trim();

    if (!input) return;

    try {

      await message.channel.sendTyping();

      const response = await generateChatCompletion(input);

      await message.reply(response);

    } catch (err) {

      console.error(chalk.red('[✗] Error replying with AI:'), err);

      await message.reply('❌ An error occurred while generating a response from AI.');

    }

  }

});

// Handle slash commands

client.on('interactionCreate', async interaction => {

  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) return;

  try {

    await command.execute(interaction);

  } catch (error) {

    console.error(chalk.red(`[✗] Error executing ${interaction.commandName}:`), error);

    await interaction.reply({

      content: 'There was an error executing that command.',

      ephemeral: true

    });

  }

});

client.login(process.env.DISCORD_TOKEN);