import { SlashCommandBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()

  .setName('delete_history')

  .setDescription('Delete chat history for yourself or this server')

  .addStringOption(option =>

    option.setName('target')

      .setDescription('Select whose history to delete')

      .setRequired(true)

      .addChoices(

        { name: 'User History', value: 'user' },

        { name: 'Server History', value: 'server' }

      )

  );

export async function execute(interaction) {

  const target = interaction.options.getString('target');

  if (target === 'user') {

    await interaction.reply({

      content: '<a:tick:1396501315907227660> Your chat history has been deleted!',

      ephemeral: true

    });

  } else if (target === 'server') {

    await interaction.reply({

      content: '<a:dustbin:1396520311742005410> Server chat history has been deleted!',

      ephemeral: false

    });

  } else {

    await interaction.reply({

      content: '<:wrong:1396519712787136666> Invalid option selected.',

      ephemeral: true

    });

  }

}