import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('pickup-line')

  .setDescription('Get a smooth or funny pickup line!');

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Give me a single clever, funny, or charming pickup line.`;

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Pickup line error:', error);

    await interaction.editReply({ content: '❌ Failed to fetch a pickup line. Please try again later.' });

  }

}