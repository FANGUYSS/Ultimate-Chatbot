import { SlashCommandBuilder } from 'discord.js';

import { generateChatCompletion } from '../services/groqService.js';

export const data = new SlashCommandBuilder()

  .setName('truth-or-dare')

  .setDescription('Get a random Truth or Dare question');

export async function execute(interaction) {

  await interaction.deferReply({ ephemeral: false });

  try {

    const prompt = `Randomly choose either "Truth" or "Dare" and provide one question or challenge accordingly for a fun party game.`;

    const response = await generateChatCompletion(prompt);

    await interaction.editReply({ content: response });

  } catch (error) {

    console.error('Truth or Dare error:', error);

    await interaction.editReply({ content: '❌ Failed to fetch a Truth or Dare. Try again later.' });

  }

}