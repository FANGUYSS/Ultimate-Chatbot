import fs from 'fs';

import path from 'path';

import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

const channelsPath = path.join(__dirname, '../data/autoChannels.json');

// Load channels

let autoChannels = {};

if (fs.existsSync(channelsPath)) {

  const data = fs.readFileSync(channelsPath);

  autoChannels = JSON.parse(data);

}

// Save channels

function saveChannels() {

  fs.writeFileSync(channelsPath, JSON.stringify(autoChannels, null, 2));

}

// Handle interaction for /set-channel

export async function handleInteraction(interaction) {

  if (!interaction.isCommand()) return;

  const { commandName } = interaction;

  if (commandName === 'set-channel') {

    const channel = interaction.options.getChannel('channel');

    autoChannels[interaction.guildId] = channel.id;

    saveChannels();

    await interaction.reply({

      content: `✅ Auto-reply channel set to <#${channel.id}>`,

      ephemeral: true,

    });

  }

}

// Auto-message reply

export async function handleAutoMessage(message) {

  if (message.author.bot || !message.guild) return;

  const autoChannel = autoChannels[message.guild.id];

  if (!autoChannel || message.channel.id !== autoChannel) return;

  message.reply('👋 Hello! I am active in this channel.');

}