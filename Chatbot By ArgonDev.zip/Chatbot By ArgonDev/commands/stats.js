import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

import os from 'os';

export const data = new SlashCommandBuilder()

  .setName('stats')

  .setDescription('Show full bot statistics like servers, users, uptime, ping, and memory');

export async function execute(interaction) {

  const client = interaction.client;

  const uptime = client.uptime;

  const totalGuilds = client.guilds.cache.size;

  const totalUsers = client.users.cache.size;

  const totalChannels = client.channels.cache.size;

  const ping = client.ws.ping;

  const memoryUsage = process.memoryUsage().rss / 1024 / 1024; // MB

  const cpuLoad = os.loadavg()[0].toFixed(2); // 1-minute load average

  const uptimeFormatted = `<t:${Math.floor((Date.now() - uptime) / 1000)}:R>`;

  const inviteLink = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot+applications.commands`;

  const botVersion = 'v1.0.0'; // You can change this manually when updating

  const embed = new EmbedBuilder()

    .setTitle('<a:stats:1396520814651768833> Bot Stats')

    .setColor('#00ffc8')

    .addFields(

      { name: '<:discord:1400083869889200260> Servers', value: `${totalGuilds}`, inline: true },

      { name: '<a:users:1396499629473792051> Cached Users', value: `${totalUsers}`, inline: true },

      { name: '<:Channels:1400084112072511570> Channels', value: `${totalChannels}`, inline: true },

      { name: '<a:ping:1396499886534426634> Ping', value: `${ping}ms`, inline: true },

      { name: '<:uptime:1400084280763482172> Uptime', value: `${uptimeFormatted}`, inline: true },

      { name: '<:Ram:1400084587706712165> RAM Usage', value: `${memoryUsage.toFixed(2)} MB`, inline: true },

      { name: '<:cpu_usage:1400084546300543029> CPU Load', value: `${cpuLoad}`, inline: true },

      { name: '<a:robot:1396498236713209858> Bot Version', value: `${botVersion}`, inline: true },

      { name: '<a:links:1396500493471060150> Invite Me', value: `[Click Here](${inviteLink})`, inline: true }

    )

    .setFooter({ text: 'Made by Argon Development ⚡' });

  await interaction.reply({ embeds: [embed] });

}